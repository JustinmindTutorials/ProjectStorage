(function(window, undefined) {

  var jimLinks = {
    "02b2f756-ae78-4be6-80db-272dfd205c88" : {
    },
    "1588a5ef-bb0c-412d-bec8-f1a537707a06" : {
      "Hotspot_1" : [
        "4d3ffd13-479c-4907-9f75-833dcabed79b",
        "f31fc3aa-6694-4a0a-aa92-3d874a872912",
        "9f6cf84b-e7cd-4901-806f-985b56ff1097",
        "21018314-2ab1-47fa-8d94-47e6173afd76",
        "2e1041d5-6bab-4de8-9736-40faa4ef60c5"
      ]
    },
    "e4f91eba-f8f8-444a-8ff7-9eea316b536c" : {
      "Hotspot_2" : [
        "4d3ffd13-479c-4907-9f75-833dcabed79b",
        "f31fc3aa-6694-4a0a-aa92-3d874a872912",
        "9f6cf84b-e7cd-4901-806f-985b56ff1097",
        "21018314-2ab1-47fa-8d94-47e6173afd76",
        "2e1041d5-6bab-4de8-9736-40faa4ef60c5"
      ],
      "Hotspot_1" : [
        "1588a5ef-bb0c-412d-bec8-f1a537707a06"
      ]
    },
    "21018314-2ab1-47fa-8d94-47e6173afd76" : {
      "Image_26" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ],
      "Send" : [
        "21018314-2ab1-47fa-8d94-47e6173afd76"
      ],
      "Hotspot_1" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ]
    },
    "9f6cf84b-e7cd-4901-806f-985b56ff1097" : {
      "Image_26" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ],
      "Attach" : [
        "9f6cf84b-e7cd-4901-806f-985b56ff1097"
      ],
      "cameraIcon" : [
        "9f6cf84b-e7cd-4901-806f-985b56ff1097"
      ],
      "Hotspot_1" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ]
    },
    "394173b4-f103-4d2b-a401-d0387300eb12" : {
      "Image_1" : [
        "02b2f756-ae78-4be6-80db-272dfd205c88"
      ]
    },
    "2e1041d5-6bab-4de8-9736-40faa4ef60c5" : {
      "Image_26" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ],
      "BgType" : [
        "2e1041d5-6bab-4de8-9736-40faa4ef60c5"
      ],
      "Attach" : [
        "2e1041d5-6bab-4de8-9736-40faa4ef60c5"
      ],
      "cameraIcon" : [
        "2e1041d5-6bab-4de8-9736-40faa4ef60c5"
      ],
      "Hotspot_1" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ]
    },
    "1f326218-4a79-47f7-8686-26c720f63ba2" : {
      "Login" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ]
    },
    "4d3ffd13-479c-4907-9f75-833dcabed79b" : {
      "Image_26" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ],
      "Hotspot_1" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ]
    },
    "55d32c7d-ced9-42af-b60f-763265513d21" : {
      "Image_1" : [
        "02b2f756-ae78-4be6-80db-272dfd205c88"
      ]
    },
    "f31fc3aa-6694-4a0a-aa92-3d874a872912" : {
      "Image_26" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ],
      "Hotspot_1" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ]
    },
    "f39803f7-df02-4169-93eb-7547fb8c961a" : {
      "Rectangle_1" : [
        "394173b4-f103-4d2b-a401-d0387300eb12"
      ],
      "Rectangle_4" : [
        "e4f91eba-f8f8-444a-8ff7-9eea316b536c"
      ],
      "Rectangle_3" : [
        "1f326218-4a79-47f7-8686-26c720f63ba2"
      ],
      "Rectangle_2" : [
        "55d32c7d-ced9-42af-b60f-763265513d21"
      ],
      "Rectangle_5" : [
        "1588a5ef-bb0c-412d-bec8-f1a537707a06"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);