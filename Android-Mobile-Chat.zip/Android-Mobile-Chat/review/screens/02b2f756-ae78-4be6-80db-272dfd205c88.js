var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f84b1243-d701-4927-a9e9-7b5e356b21b8" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template No SlideMenu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-02b2f756-ae78-4be6-80db-272dfd205c88" class="screen growth-vertical devMobile canvas PORTRAIT firer pageload ie-background commentable non-processed" alignment="center" name="Opened Image" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/02b2f756-ae78-4be6-80db-272dfd205c88-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/02b2f756-ae78-4be6-80db-272dfd205c88-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/02b2f756-ae78-4be6-80db-272dfd205c88-1584566042059-ie8.css" /><![endif]-->\
      <div id="s-Bg" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Bg_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Horizontal-softkeys" class="pie dynamicpanel firer commentable pin vpin-end hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="48px" dataX="0" dataY="0" >\
        <div id="s-Panel_1" class="pie panel default firer commentable non-processed"  datasizewidth="360px" datasizeheight="48px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="263" dataY="9"   alt="image">\
                  <img src="./images/b9ed4dca-fecf-45c4-b969-74c905d2f1b8.png" />\
              </div>\
\
              <div id="s-Image_23" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="161" dataY="9"   alt="image">\
                  <img src="./images/ba98c936-79b7-46f9-b942-b1c0f4f3401c.png" />\
              </div>\
\
              <div id="s-Image_24" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="63" dataY="9"   alt="image">\
                  <img src="./images/82022295-77ec-4198-b841-f7110386648b.png" />\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Delete" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="295" dataY="538"   alt="image" systemName="./images/748e9778-c650-46b3-abc1-46fc22ed497d.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>\
      </div>\
      <div id="s-Share" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="36" dataY="538"   alt="image" systemName="./images/bec47190-c8ca-41e0-82cc-66737a81bc2a.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg>\
      </div>\
      <div id="s-Info" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="208" dataY="538"   alt="image" systemName="./images/97fdb468-f600-47b3-bc0d-aac9a88ae321.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M11 17h2v-6h-2v6zm1-15C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zM11 9h2V7h-2v2z"/></svg>\
      </div>\
      <div id="s-Tune" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="122" dataY="538"   alt="image" systemName="./images/b1d6630e-1a15-4ba3-9bd9-c79d4d868940.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"/></svg>\
      </div>\
\
      <div id="s-Picture" class="pie image firer ie-background commentable non-processed" name="Image"  datasizewidth="360px" datasizeheight="360px" dataX="0" dataY="118"   alt="image">\
          <img src="{{!it.userdata["Image"]}}" />\
      </div>\
      <div id="s-More_Vertical" class="pie image firer click ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="320" dataY="34"   alt="image" systemName="./images/97328a81-108f-433b-8013-0c8ecd0a5367.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-More_Menu" class="group firer ie-background commentable hidden non-processed" datasizewidth="164px" datasizeheight="220px" dataX="196" dataY="1" >\
        <div id="s-Bg_6" class="pie rectangle firer commentable non-processed"   datasizewidth="164px" datasizeheight="220px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_6_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_1" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_1_0">Print</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_2" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="44" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_2_0">Export to PDF</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_3" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="87" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_3_0">Rename</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_4" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="131" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_4_0">Rotate</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_5" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="175" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_5_0">Configure as</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;