var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="center" name="Template SlideMenu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059-ie8.css" /><![endif]-->\
      <div id="t-Menu" class="pie image firer click windowscroll ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="39px" dataX="19" dataY="29"   alt="image" systemName="./images/1a285333-4d0a-4229-8ad4-3a82b1d036b1.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
      </div>\
      <div id="t-Slidemenu" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="250px" datasizeheight="593px" dataX="-270" dataY="0" >\
        <div id="t-Panel_3" class="pie panel default firer windowscroll ie-background commentable non-processed"  datasizewidth="250px" datasizeheight="593px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="t-BG_1" class="pie rectangle firer commentable non-processed"   datasizewidth="250px" datasizeheight="593px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-BG_1_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_1" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="130" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_1_0">Profile</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_4" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="81" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_4_0">Chats</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_3" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="543" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_3_0">Sign out</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_2" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="179" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_2_0">Files</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Image_17" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="192"   alt="image" systemName="./images/47c731f4-eb84-4a07-9eaf-8bf9f076a8f5.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54-1.96-2.36L6.5 17h11l-3.54-4.71z"/></svg>\
              </div>\
              <div id="t-Image_71" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="94"   alt="image" systemName="./images/52ffc3da-fa29-47d3-844c-8ce41eb837ee.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>\
              </div>\
              <div id="t-Image_96" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="556"  rotationdeg="180" alt="image" systemName="./images/699c4285-f9f1-4fc6-bd98-d22475fd8271.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/></svg>\
              </div>\
              <div id="t-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="143"   alt="image" systemName="./images/9ecc2183-0b1f-4c74-a756-ec511da80569.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>\
              </div>\
              <div id="t-Menu_close" class="pie image firer click ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="39px" dataX="14" dataY="29"   alt="image" systemName="./images/1a285333-4d0a-4229-8ad4-3a82b1d036b1.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
              </div>\
              <div id="t-Rectangle_5" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="228" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_5_0">Contacts</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Image_74" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="241"   alt="image" systemName="./images/dd2fc175-fadf-4214-aece-f6bea0e681a0.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="t-cover" class="pie rectangle firer click windowscroll commentable hidden non-processed"   datasizewidth="110px" datasizeheight="593px" dataX="250" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-cover_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-e4f91eba-f8f8-444a-8ff7-9eea316b536c" class="screen growth-vertical devMobile canvas PORTRAIT firer pageload ie-background commentable non-processed" alignment="center" name="Chats List" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e4f91eba-f8f8-444a-8ff7-9eea316b536c-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/e4f91eba-f8f8-444a-8ff7-9eea316b536c-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/e4f91eba-f8f8-444a-8ff7-9eea316b536c-1584566042059-ie8.css" /><![endif]-->\
      <div id="s-Chats_List" class="pie dynamicpanel firer ie-background commentable pin vpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="512px" dataX="0" dataY="81" >\
        <div id="s-Chats" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="512px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-chats" summary="" class="pie datagrid horizontal firer ie-background commentable non-processed" items="1" size="0" childWidth="360" childHeight="97" hSpacing="0" vSpacing="0" datamaster="chatsList" datasizewidth="360px" datasizeheight="291px" dataX="0" dataY="30" originalwidth="360px" originalheight="291px" >\
                <div class="backgroundLayer"></div>\
                <table >\
                </table>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-butt_AllContacts" class="group firer ie-background commentable non-processed" datasizewidth="89px" datasizeheight="89px" dataX="244" dataY="488" >\
        <div id="s-Fill_81" class="pie image firer ie-background commentable non-processed"   datasizewidth="89px" datasizeheight="89px" dataX="0" dataY="0"   alt="image" systemName="./images/00e02e26-cb32-4c70-a9e3-c7b8e1369a0d.svg" overlay="#6F6FDB">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="89px" height="89px" viewBox="0 0 89 89" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                <title>Fill 1</title>\
                <desc>Created with Sketch.</desc>\
                <defs>\
                    <filter x="-14.7%" y="-13.2%" width="129.3%" height="128.9%" filterUnits="objectBoundingBox" id="s-Fill_81-filter-1">\
                        <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>\
                        <feGaussianBlur stdDeviation="3.5" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>\
                        <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.278334466 0" type="matrix" in="shadowBlurOuter1" result="shadowMatrixOuter1"></feColorMatrix>\
                        <feMerge>\
                            <feMergeNode in="shadowMatrixOuter1"></feMergeNode>\
                            <feMergeNode in="SourceGraphic"></feMergeNode>\
                        </feMerge>\
                    </filter>\
                </defs>\
                <g id="s-Fill_81-Contacts-chat---selected-contact" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-246.000000, -468.000000)">\
                    <g id="s-Fill_81-all-contacts-button" filter="url(#s-Fill_81-filter-1)" transform="translate(253.000000, 473.000000)" fill="#6F6FDB">\
                        <g id="s-Fill_81-Group-3" transform="translate(0.000000, 0.988300)">\
                            <path d="M-0.0002,37.5055 C-0.0002,16.7985 16.7868,0.0115 37.4938,0.0115 C58.2018,0.0115 74.9878,16.7985 74.9878,37.5055 C74.9878,58.2135 58.2018,74.9995 37.4938,74.9995 C16.7868,74.9995 -0.0002,58.2135 -0.0002,37.5055" id="s-Fill_81-Fill-1"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Fill_82" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="44px" dataX="22" dataY="22"   alt="image" systemName="./images/7a3aac2e-f624-4118-9f31-5827124a3c16.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="45px" height="44px" viewBox="0 0 45 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                <title>Fill 4</title>\
                <desc>Created with Sketch.</desc>\
                <defs>\
                    <filter x="-14.7%" y="-13.2%" width="129.3%" height="128.9%" filterUnits="objectBoundingBox" id="s-Fill_82-filter-1">\
                        <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>\
                        <feGaussianBlur stdDeviation="3.5" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>\
                        <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.278334466 0" type="matrix" in="shadowBlurOuter1" result="shadowMatrixOuter1"></feColorMatrix>\
                        <feMerge>\
                            <feMergeNode in="shadowMatrixOuter1"></feMergeNode>\
                            <feMergeNode in="SourceGraphic"></feMergeNode>\
                        </feMerge>\
                    </filter>\
                </defs>\
                <g id="s-Fill_82-Contacts-chat---selected-contact" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-269.000000, -491.000000)">\
                    <g id="s-Fill_82-all-contacts-button" filter="url(#s-Fill_82-filter-1)" transform="translate(253.000000, 473.000000)" fill="#FFFFFF">\
                        <path d="M23.1644,54.9518 L23.1644,53.4248 C23.1644,45.0598 23.1624,36.6968 23.1664,28.3328 C23.1674,25.8608 24.1774,24.8638 26.6834,24.8618 C34.4664,24.8578 42.2484,24.8568 50.0304,24.8618 C52.4984,24.8638 53.5284,25.8968 53.5314,28.3708 C53.5374,34.1398 53.5384,39.9098 53.5304,45.6798 C53.5274,47.9758 52.4624,49.0488 50.1724,49.0518 C43.6424,49.0608 37.1124,49.0798 30.5824,49.0318 C29.4554,49.0238 28.6424,49.3518 27.8814,50.1688 C26.4344,51.7238 24.9014,53.1998 23.1644,54.9518" id="s-Fill_82-Fill-4"></path>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="77px" datasizeheight="77px" dataX="6" dataY="6"  >\
            <div class="clickableSpot"></div>\
        </div>\
      </div>\
      <div id="s-Horizontal-softkeys" class="pie dynamicpanel firer commentable pin vpin-end hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="48px" dataX="0" dataY="0" >\
        <div id="s-Panel_1" class="pie panel default firer commentable non-processed"  datasizewidth="360px" datasizeheight="48px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="263" dataY="9"   alt="image">\
                  <img src="./images/b9ed4dca-fecf-45c4-b969-74c905d2f1b8.png" />\
              </div>\
\
              <div id="s-Image_23" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="161" dataY="9"   alt="image">\
                  <img src="./images/ba98c936-79b7-46f9-b942-b1c0f4f3401c.png" />\
              </div>\
\
              <div id="s-Image_24" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="63" dataY="9"   alt="image">\
                  <img src="./images/82022295-77ec-4198-b841-f7110386648b.png" />\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Topbar" class="pie dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="98px" dataX="0" dataY="0" >\
        <div id="s-Panel_Search" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="98px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Bg" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="81px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Bg_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="s-Profile" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="104px" datasizeheight="24px" dataX="70" dataY="37" >\
                <div class="backgroundLayer"></div>\
                <div class="paddingLayer">\
                  <div class="clipping">\
                    <div class="content">\
                      <div class="valign">\
                        <span id="rtr-s-Profile_0">Chats</span>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
              </div>\
              <div id="s-Menu_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="320" dataY="34"   alt="image" systemName="./images/35a176df-8b17-42db-a602-9ba7a22555ce.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
              </div>\
              <div id="s-InputSearch" class="group firer ie-background commentable hidden non-processed" datasizewidth="162px" datasizeheight="36px" dataX="165" dataY="33" >\
                <div id="s-InputBg" class="pie rectangle firer commentable non-processed"   datasizewidth="162px" datasizeheight="36px" dataX="0" dataY="0" >\
                 <div class="backgroundLayer"></div>\
                 <div class="paddingLayer">\
                   <div class="clipping">\
                     <div class="content">\
                       <div class="valign">\
                         <span id="rtr-s-InputBg_0"></span>\
                       </div>\
                     </div>\
                   </div>\
                 </div>\
                </div>\
                <div id="s-InputSearchChats" class="pie text firer keyup ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="27px" dataX="9" dataY="7" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search chats"/></div></div>  </div></div>\
              </div>\
              <div id="s-ShowSearch" class="pie image firer toggle ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="21px" dataX="291" dataY="39"   alt="image" systemName="./images/08897210-f09e-482a-8f01-b997b2fbb10d.svg" overlay="#FFFFFF">\
                  <?xml version="1.0" encoding="UTF-8"?>\
                  <svg preserveAspectRatio=\'none\' width="21px" height="21px" viewBox="0 0 21 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                      <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                      <title>search-icon</title>\
                      <desc>Created with Sketch.</desc>\
                      <defs></defs>\
                      <g id="s-ShowSearch-All-contacts" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-280.000000, -41.000000)">\
                          <g id="s-ShowSearch-header" transform="translate(0.000000, 20.000000)" fill="#FFFFFF">\
                              <path d="M288.860041,36.8423855 C285.008053,36.8423855 281.874239,33.7103301 281.874239,29.8604899 C281.874239,26.0082641 285.008053,22.8743344 288.860041,22.8743344 C292.712028,22.8743344 295.845842,26.0082641 295.845842,29.8604899 C295.845842,33.7103301 292.712028,36.8423855 288.860041,36.8423855 M300.725722,40.4095421 L295.74868,35.4322471 C297.020394,33.8606177 297.720081,31.8843024 297.720081,29.8604899 C297.720081,24.9747817 293.745458,21 288.860041,21 C283.974623,21 280,24.9747817 280,29.8604899 C280,34.7461555 283.974623,38.7209798 288.860041,38.7209798 C290.884389,38.7209798 292.859071,38.0227476 294.427256,36.7536954 L299.404341,41.7267305 C299.586525,41.908967 299.825832,42.0000426 300.065095,42 C300.304274,42 300.543452,41.908967 300.725424,41.7270287 C300.902497,41.5521619 301,41.3181257 301,41.0680724 C301,40.8181895 300.902582,40.5843237 300.725722,40.4095421" id="s-ShowSearch-search-icon"></path>\
                          </g>\
                      </g>\
                  </svg>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_Options" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="98px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_1" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="81px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_1_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="s-Paragraph_1" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="104px" datasizeheight="24px" dataX="70" dataY="37" >\
                <div class="backgroundLayer"></div>\
                <div class="paddingLayer">\
                  <div class="clipping">\
                    <div class="content">\
                      <div class="valign">\
                        <span id="rtr-s-Paragraph_1_0">Chat</span>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
              </div>\
              <div id="s-Delete" class="pie image firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="274" dataY="39"   alt="image" systemName="./images/544117ba-2bdc-4b23-bb0a-b38aa5db644f.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>\
              </div>\
              <div id="s-Mute" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="320" dataY="39"   alt="image" systemName="./images/85f2a757-05e9-43ae-a652-cad2c652ecc2.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Statusbar" class="pie dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
        <div id="s-Panel_4" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="20px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Bg_1" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="81px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Bg_1_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
\
              <div id="s-Icons_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="253" dataY="0"   alt="image">\
                  <img src="./images/07bba335-9509-42a8-b78b-188d80774497.png" />\
              </div>\
              <div id="s-Label_30" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="314" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Label_30_0">15:45</span></div></div></div></div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-More_Menu" class="group firer ie-background commentable hidden non-processed" datasizewidth="164px" datasizeheight="132px" dataX="196" dataY="1" >\
        <div id="s-Bg_6" class="pie rectangle firer commentable non-processed"   datasizewidth="164px" datasizeheight="132px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_6_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_2" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_2_0">New Group</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_3" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="44" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_3_0">WebApp</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_4" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="87" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_4_0">Setings</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-chats-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="pie gridcell firer ie-background commentable non-processed " instance="{{=it.id}}" originalwidth="360px" originalheight="97px" >\
              <div class="layout scrollable">\
                  <div id="s-Image_1" class="pie image firer ie-background commentable hidden non-processed" name="Picture"  datasizewidth="69px" datasizeheight="69px" dataX="30" dataY="10"   alt="image">\
                      <img src="{{!it.userdata["Picture"]}}" />\
                  </div>\
                  <div id="s-Input_2" class="pie text firer ie-background commentable hidden non-processed"  datasizewidth="224px" datasizeheight="26px" dataX="114" dataY="22" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Name" value="{{!it.userdata["Name"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
                  <div id="s-Input_3" class="pie text firer ie-background commentable hidden non-processed"  datasizewidth="224px" datasizeheight="26px" dataX="114" dataY="47" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Status" value="{{!it.userdata["Status"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
                    <div id="s-Input_4" class="pie checkbox firer commentable hidden non-processed nonMobile" datasizewidth="13px" datasizeheight="13px" dataX="114" dataY="66" >\
                      <input class="checkBoxInput" type="checkbox"  name="Checked" value="{{!it.userdata["Checked"]}}" disabled="disabled" {{? jimData.isTrue(it.userdata["Checked"]) }}checked="checked"{{?}} tabindex="-1" />\
                    </div>\
\
                  <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="315px" datasizeheight="1px" dataX="22" dataY="96" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                          <g>\
                              <g>\
                                  <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable hidden non-processed" d="M 0 0 L 315 0"  >\
                                  </path>\
                              </g>\
                          </g>\
                          <defs>\
                          </defs>\
                      </svg>\
                  </div>\
                  <div id="s-Input_8" class="pie text firer ie-background commentable hidden non-processed"  datasizewidth="42px" datasizeheight="20px" dataX="295" dataY="77" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="TimeLastChat" value="{{!it.userdata["TimeLastChat"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
                  <div id="s-Hotspot_2" class="imagemap firer taphold click ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="97px" dataX="0" dataY="0"  >\
                      <div class="clickableSpot"></div>\
                  </div>\
                  <div id="s-selecticon_1" class="group firer ie-background commentable hidden non-processed" datasizewidth="25px" datasizeheight="25px" dataX="77" dataY="58" >\
                    <div id="s-Fill_83" class="pie image firer ie-background commentable non-processed"   datasizewidth="19px" datasizeheight="19px" dataX="3" dataY="2"   alt="image" systemName="./images/a06025a8-5841-4ed8-99c1-e0c1f030af26.svg" overlay="#6F6FDB">\
                        <?xml version="1.0" encoding="UTF-8"?>\
                        <svg preserveAspectRatio=\'none\' width="19px" height="19px" viewBox="0 0 19 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                            <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                            <title>Fill 1</title>\
                            <desc>Created with Sketch.</desc>\
                            <defs></defs>\
                            <g id="s-Fill_83-Contacts-chat---selected-contact" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-71.000000, -254.000000)">\
                                <g id="s-Fill_83-select-icon" transform="translate(71.000000, 254.000000)" fill="#6F6FDB">\
                                    <path d="M0,9.3515625 C0,4.187125 4.187125,0 9.3515625,0 C14.516,0 18.703125,4.187125 18.703125,9.3515625 C18.703125,14.516 14.516,18.703125 9.3515625,18.703125 C4.187125,18.703125 0,14.516 0,9.3515625" id="s-Fill_83-Fill-1"></path>\
                                </g>\
                            </g>\
                        </svg>\
                    </div>\
                    <div id="s-Fill_84" class="pie image firer ie-background commentable non-processed"   datasizewidth="13px" datasizeheight="10px" dataX="6" dataY="7"   alt="image" systemName="./images/8d6c81c4-023a-4fa4-aca9-efef45ae7706.svg" overlay="#FFFFFF">\
                        <?xml version="1.0" encoding="UTF-8"?>\
                        <svg preserveAspectRatio=\'none\' width="13px" height="10px" viewBox="0 0 13 10" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                            <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                            <title>Fill 3</title>\
                            <desc>Created with Sketch.</desc>\
                            <defs></defs>\
                            <g id="s-Fill_84-Contacts-chat---selected-contact" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-74.000000, -259.000000)">\
                                <g id="s-Fill_84-select-icon" transform="translate(71.000000, 254.000000)" fill="#FFFFFF">\
                                    <path d="M3.78687813,10.3019188 C3.69662813,10.2122625 3.65150313,10.0768875 3.65150313,9.9866375 C3.65150313,9.8963875 3.69662813,9.7610125 3.78687813,9.67135625 L4.41744063,9.0402 C4.59794063,8.8597 4.86869063,8.8597 5.04919063,9.0402 L5.09372188,9.08473125 L7.57322188,11.7447313 C7.66287813,11.8349813 7.79884688,11.8349813 7.88850313,11.7447313 L13.9287219,5.4788875 L13.9738469,5.4788875 C14.1543469,5.29898125 14.4245031,5.29898125 14.6050031,5.4788875 L15.2361594,6.11004375 C15.4166594,6.29054375 15.4166594,6.5607 15.2361594,6.7412 L8.02387813,14.2236375 C7.93362813,14.3138875 7.84337813,14.3590125 7.70800313,14.3590125 C7.57322188,14.3590125 7.48297188,14.3138875 7.39272188,14.2236375 L3.87653438,10.4378875 L3.78687813,10.3019188 Z" id="s-Fill_84-Fill-3"></path>\
                                </g>\
                            </g>\
                        </svg>\
                    </div>\
                    <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="25px" datasizeheight="25px" dataX="0" dataY="0"  >\
                        <div class="clickableSpot"></div>\
                    </div>\
                  </div>\
\
               </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;