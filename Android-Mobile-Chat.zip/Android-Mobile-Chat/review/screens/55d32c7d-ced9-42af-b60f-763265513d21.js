var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="center" name="Template SlideMenu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059-ie8.css" /><![endif]-->\
      <div id="t-Menu" class="pie image firer click windowscroll ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="39px" dataX="19" dataY="29"   alt="image" systemName="./images/1a285333-4d0a-4229-8ad4-3a82b1d036b1.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
      </div>\
      <div id="t-Slidemenu" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="250px" datasizeheight="593px" dataX="-270" dataY="0" >\
        <div id="t-Panel_3" class="pie panel default firer windowscroll ie-background commentable non-processed"  datasizewidth="250px" datasizeheight="593px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="t-BG_1" class="pie rectangle firer commentable non-processed"   datasizewidth="250px" datasizeheight="593px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-BG_1_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_1" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="130" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_1_0">Profile</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_4" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="81" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_4_0">Chats</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_3" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="543" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_3_0">Sign out</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_2" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="179" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_2_0">Files</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Image_17" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="192"   alt="image" systemName="./images/47c731f4-eb84-4a07-9eaf-8bf9f076a8f5.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54-1.96-2.36L6.5 17h11l-3.54-4.71z"/></svg>\
              </div>\
              <div id="t-Image_71" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="94"   alt="image" systemName="./images/52ffc3da-fa29-47d3-844c-8ce41eb837ee.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>\
              </div>\
              <div id="t-Image_96" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="556"  rotationdeg="180" alt="image" systemName="./images/699c4285-f9f1-4fc6-bd98-d22475fd8271.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/></svg>\
              </div>\
              <div id="t-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="143"   alt="image" systemName="./images/9ecc2183-0b1f-4c74-a756-ec511da80569.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>\
              </div>\
              <div id="t-Menu_close" class="pie image firer click ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="39px" dataX="14" dataY="29"   alt="image" systemName="./images/1a285333-4d0a-4229-8ad4-3a82b1d036b1.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
              </div>\
              <div id="t-Rectangle_5" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="228" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_5_0">Contacts</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Image_74" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="241"   alt="image" systemName="./images/dd2fc175-fadf-4214-aece-f6bea0e681a0.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="t-cover" class="pie rectangle firer click windowscroll commentable hidden non-processed"   datasizewidth="110px" datasizeheight="593px" dataX="250" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-cover_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-55d32c7d-ced9-42af-b60f-763265513d21" class="screen growth-vertical devMobile canvas PORTRAIT firer pageload ie-background commentable non-processed" alignment="center" name="Image Gallery" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/55d32c7d-ced9-42af-b60f-763265513d21-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/55d32c7d-ced9-42af-b60f-763265513d21-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/55d32c7d-ced9-42af-b60f-763265513d21-1584566042059-ie8.css" /><![endif]-->\
      <div id="s-Horizontal-softkeys" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="48px" dataX="0" dataY="592" >\
        <div id="s-Rectangle_19" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_19_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
\
        <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="263" dataY="9"   alt="image">\
            <img src="./images/b9ed4dca-fecf-45c4-b969-74c905d2f1b8.png" />\
        </div>\
\
        <div id="s-Image_23" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="161" dataY="9"   alt="image">\
            <img src="./images/ba98c936-79b7-46f9-b942-b1c0f4f3401c.png" />\
        </div>\
\
        <div id="s-Image_24" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="63" dataY="9"   alt="image">\
            <img src="./images/82022295-77ec-4198-b841-f7110386648b.png" />\
        </div>\
      </div>\
      <div id="s-Topbar" class="pie dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="98px" dataX="0" dataY="0" >\
        <div id="s-Panel_Options" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="98px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Bg_Top" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="81px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Bg_Top_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="s-Title" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="142px" datasizeheight="32px" dataX="70" dataY="37" >\
                <div class="backgroundLayer"></div>\
                <div class="paddingLayer">\
                  <div class="clipping">\
                    <div class="content">\
                      <div class="valign">\
                        <span id="rtr-s-Title_0">Image Gallery</span>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
              </div>\
              <div id="s-Options" class="group firer ie-background commentable hidden non-processed" datasizewidth="68px" datasizeheight="24px" dataX="275" dataY="39" >\
                <div id="s-Delete" class="pie image firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="44" dataY="0"   alt="image" systemName="./images/544117ba-2bdc-4b23-bb0a-b38aa5db644f.svg" overlay="#FFFFFF">\
                    <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>\
                </div>\
                <div id="s-Image_20" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="0" dataY="0"   alt="image" systemName="./images/1f0b2346-feac-451b-b6c0-ac057900d1cd.svg" overlay="#FFFFFF">\
                    <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg>\
                </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Statusbar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
        <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_2_0"><br /></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Dynamic_Panel_3" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="s-Panel_4" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="20px" >\
            <div class="backgroundLayer"></div>\
            <div class="layoutWrapper scrollable">\
                <table class="layout" summary="">\
                  <tr>\
                    <td class="layout horizontal insertionpoint verticalalign Panel_4 Dynamic_Panel_3" valign="top" align="right" hSpacing="0" vSpacing="0">\
                <div id="s-Icons_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="253" dataY="0"   alt="image">\
                    <img src="./images/07bba335-9509-42a8-b78b-188d80774497.png" />\
                </div><div id="s-Label_30" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="314" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Label_30_0">15:45</span></div></div></div></div></td> \
                  </tr>\
                </table>\
\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-fullGallery" class="pie percentage dynamicpanel firer ie-background commentable non-processed-percentage non-processed" datasizewidth="100%" datasizeheight="511px" dataX="0" dataY="81" >\
        <div id="s-Gallery" class="pie percentage panel default firer ie-background commentable non-processed-percentage non-processed"  datasizewidth="100%" datasizeheight="511px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <table class="layout" summary="">\
                <tr>\
                  <td class="layout vertical insertionpoint verticalalign Gallery fullGallery" valign="top" align="left" hSpacing="0" vSpacing="0"><div id="s-Gallery_1" summary="" class="pie percentage datagrid horizontal firer ie-background commentable non-processed-percentage non-processed" items="3" size="0" childWidth="111" childHeight="116" hSpacing="5" vSpacing="5" datamaster="fullGallery" datasizewidth="98%" datasizeheight="731px" dataX="0" dataY="24" originalwidth="343px" originalheight="721px" >\
                <div class="backgroundLayer"></div>\
                <table >\
                </table>\
              </div></td> \
                </tr>\
              </table>\
\
          </div>\
        </div>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-Gallery_1-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="pie gridcell firer commentable non-processed " instance="{{=it.id}}" originalwidth="111px" originalheight="116px" >\
              <div class="layout scrollable">\
                  <div id="s-Image_1" class="pie percentage image firer taphold click ie-background commentable non-processed-percentage non-processed" name="Image"  datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0"   alt="image">\
                      <img src="{{!it.userdata["Image"]}}" />\
                  </div>\
\
                    <div id="s-Input_1" class="pie checkbox firer commentable hidden non-processed nonMobile" datasizewidth="13px" datasizeheight="13px" dataX="89" dataY="94" >\
                      <input class="checkBoxInput" type="checkbox"  name="Checked" value="{{!it.userdata["Checked"]}}"  {{? jimData.isTrue(it.userdata["Checked"]) }}checked="checked"{{?}} tabindex="-1" />\
                    </div>\
\
\
               </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;