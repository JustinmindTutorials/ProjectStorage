var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f84b1243-d701-4927-a9e9-7b5e356b21b8" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template No SlideMenu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-21018314-2ab1-47fa-8d94-47e6173afd76" class="screen growth-vertical devMobile canvas PORTRAIT firer commentable non-processed" alignment="center" name="Chat-Eli" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/21018314-2ab1-47fa-8d94-47e6173afd76-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/21018314-2ab1-47fa-8d94-47e6173afd76-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/21018314-2ab1-47fa-8d94-47e6173afd76-1584566042059-ie8.css" /><![endif]-->\
      <div id="s-Horizontal-softkeys" class="pie dynamicpanel firer commentable pin vpin-end hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="48px" dataX="0" dataY="0" >\
        <div id="s-Panel_1" class="pie panel default firer commentable non-processed"  datasizewidth="360px" datasizeheight="48px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Image_9" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="263" dataY="9"   alt="image">\
                  <img src="./images/b9ed4dca-fecf-45c4-b969-74c905d2f1b8.png" />\
              </div>\
\
              <div id="s-Image_25" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="161" dataY="9"   alt="image">\
                  <img src="./images/ba98c936-79b7-46f9-b942-b1c0f4f3401c.png" />\
              </div>\
\
              <div id="s-Image_26" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="63" dataY="9"   alt="image">\
                  <img src="./images/82022295-77ec-4198-b841-f7110386648b.png" />\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-typeOptions" class="group firer ie-background commentable non-processed" datasizewidth="327px" datasizeheight="46px" dataX="17" dataY="530" >\
        <div id="s-BgType" class="pie rectangle firer commentable non-processed"   datasizewidth="271px" datasizeheight="46px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-BgType_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Smile" class="pie image firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="21px" dataX="16" dataY="12"   alt="image" systemName="./images/60e5de5a-688a-4ef3-86a7-205523ca00e3.svg" overlay="#BBBBBB">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="21px" height="21px" viewBox="0 0 21 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                <title>Fill 1</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Smile-Chat" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-36.000000, -542.000000)">\
                    <g id="s-Smile-input-message" transform="translate(17.000000, 530.000000)" fill="#BBBBBB">\
                        <g id="s-Smile-icons" transform="translate(19.000000, 12.000000)">\
                            <path d="M14.9191458,12.5742701 C14.1649121,14.3184477 12.398557,15.4453822 10.4194542,15.4453822 C8.39776262,15.4453822 6.62100561,14.3125598 5.89287477,12.5597467 C5.7682486,12.2594664 5.91053832,11.9150271 6.21081869,11.7902047 C6.28461308,11.7597841 6.3613514,11.7450645 6.43651963,11.7450645 C6.66751963,11.7450645 6.8863514,11.8816626 6.98036075,12.1083449 C7.5255757,13.4205505 8.87546355,14.2680084 10.4194542,14.2680084 C11.9289028,14.2680084 13.2709402,13.4199617 13.8383327,12.1067748 C13.9674729,11.808457 14.314071,11.6706813 14.612585,11.800214 C14.9107065,11.9295505 15.048286,12.2757561 14.9191458,12.5742701 M12.0421458,7.58981215 C12.0421458,6.91781215 12.5873607,6.37279346 13.2593607,6.37279346 C13.9313607,6.37279346 14.4761832,6.91761589 14.4761832,7.58981215 C14.4761832,8.26220467 13.931557,8.8070271 13.2593607,8.8070271 C12.5873607,8.8070271 12.0421458,8.26220467 12.0421458,7.58981215 M6.52385607,7.58981215 C6.52385607,6.91781215 7.0686785,6.37279346 7.7406785,6.37279346 C8.41248224,6.37279346 8.9576972,6.91761589 8.9576972,7.58981215 C8.9576972,8.26220467 8.41248224,8.8070271 7.7406785,8.8070271 C7.0686785,8.8070271 6.52385607,8.26220467 6.52385607,7.58981215 M16.6344729,16.634728 C13.201071,20.0683262 7.61428598,20.0687187 4.18068785,16.6351206 C0.746697196,13.2011299 0.74708972,7.61395234 4.18068785,4.18035421 C7.61408972,0.74734486 13.2006785,0.746952336 16.6348654,4.18074673 C20.0682673,7.61434486 20.0678748,13.2015224 16.6344729,16.634728 M17.7706318,3.04576542 C13.7105664,-1.01488879 7.10459439,-1.01488879 3.04511776,3.04478411 C-1.01514393,7.10445701 -1.01494766,13.7106252 3.04531402,17.7710832 C7.10459439,21.8305598 13.7105664,21.8305598 17.7702393,17.7702981 C21.8303047,13.7106252 21.8299121,7.10484953 17.7706318,3.04576542" id="s-Smile-Fill-1"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Attach" class="pie image firer click ie-background commentable hidden non-processed"   datasizewidth="25px" datasizeheight="22px" dataX="232" dataY="11"   alt="image" systemName="./images/c4559ff5-9515-4ee8-b224-0af117d4c1d7.svg" overlay="#6F6FDB">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="25px" height="22px" viewBox="0 0 25 22" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                <title>Fill 1</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Attach-Chat" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-249.000000, -541.000000)">\
                    <g id="s-Attach-input-message" transform="translate(17.000000, 530.000000)" fill="#6F6FDB">\
                        <g id="s-Attach-attached-icon" transform="translate(232.000000, 11.000000)">\
                            <path d="M23.1086949,1.83278995 C20.5869548,-0.610929984 16.4976619,-0.610929984 13.975993,1.83278995 L1.41905285,14.0011616 C-0.473017616,15.8346242 -0.473017616,18.8056009 1.41905285,20.6392016 C2.97856033,22.1503904 5.33077948,22.3944933 7.1695943,21.413597 C7.36168484,21.4042138 7.5505715,21.3338393 7.6975229,21.1929523 L20.2543918,9.02464966 C21.5152263,7.80282419 21.5152263,5.82219604 20.2543918,4.60037057 C18.9935573,3.3785451 16.9496941,3.3785451 15.6888596,4.60037057 L5.4147212,14.5565681 C5.09988637,14.8616623 5.09988637,15.3575265 5.4147212,15.6626207 C5.72955603,15.9677148 6.24132282,15.9677148 6.55608645,15.6626207 L16.8301537,5.70642309 C17.4614609,5.09471692 18.4833569,5.09471692 19.1130266,5.70642309 C19.7442626,6.31812927 19.7442626,7.30840884 19.1130266,7.91859714 L7.1260215,19.5345979 C5.86518704,20.7564234 3.82132376,20.7564234 2.5604893,19.5345979 C1.29965484,18.3127725 1.29965484,16.3321443 2.5604893,15.1103189 L15.1173582,2.93884248 C17.0094287,1.10531083 20.075188,1.10531083 21.9673297,2.93884248 C23.8594001,4.77237412 23.8594001,7.74328184 21.9673297,9.57688248 L10.551826,20.6392016 C10.2369912,20.9442957 10.2369912,21.44016 10.551826,21.7451851 C10.8666608,22.0503482 11.3784276,22.0503482 11.6931913,21.7451851 L23.1086949,10.682935 C25.630435,8.23928406 25.630435,4.27650989 23.1086949,1.83278995" id="s-Attach-Fill-1"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Send" class="pie image lockV firer click ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="235" dataY="11" aspectRatio="1.0"   alt="image" systemName="./images/702fc7c5-6c82-4206-85a2-d6487ff55352.svg" overlay="#6F6EDB">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>\
        </div>\
        <div id="shapewrapper-s-bgCamera" class="shapewrapper shapewrapper-s-bgCamera non-processed"   datasizewidth="44px" datasizeheight="44px" dataX="283" dataY="1" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-bgCamera" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-bgCamera)">\
                            <ellipse id="s-bgCamera" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="22.0" cy="22.0" rx="22.0" ry="22.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-bgCamera" class="clipPath">\
                            <ellipse cx="22.0" cy="22.0" rx="22.0" ry="22.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-bgCamera" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-bgCamera_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-cameraIcon" class="pie image firer click ie-background commentable non-processed"   datasizewidth="23px" datasizeheight="23px" dataX="293" dataY="11"   alt="image" systemName="./images/f7548274-b707-47e4-ba6c-adf424af4e37.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/></svg>\
        </div>\
        <div id="s-chatInputText" class="pie textarea firer focusout focusin commentable non-processed"  datasizewidth="177px" datasizeheight="33px" dataX="46" dataY="7" ><div class="backgroundLayer"></div><textarea   tabindex="-1" placeholder=""></textarea></div>\
      </div>\
      <div id="s-chatScroll" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="370px" dataX="0" dataY="141" >\
        <div id="s-chatContainer" class="pie panel default firer pageload ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="370px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <table class="layout" summary="">\
                <tr>\
                  <td class="layout vertical insertionpoint verticalalign chatContainer chatScroll" valign="bottom" align="center" hSpacing="0" vSpacing="5"><div id="s-chatDialogsProcess" summary="" class="pie datagrid horizontal firer ie-background commentable non-processed" items="1" size="0" childWidth="343" childHeight="165" hSpacing="0" vSpacing="18" datamaster="chatDialogs-Emily" datasizewidth="343px" datasizeheight="384px" dataX="0" dataY="0" originalwidth="343px" originalheight="348px" >\
                <div class="backgroundLayer"></div>\
                <table >\
                </table>\
              </div><div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="200px" datasizeheight="1px" dataX="71" dataY="389" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                      <g>\
                          <g>\
                              <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 200 0"  >\
                              </path>\
                          </g>\
                      </g>\
                      <defs>\
                      </defs>\
                  </svg>\
              </div></td> \
                </tr>\
              </table>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Attachment" summary="" class="pie datagrid horizontal firer commentable hidden non-processed" items="4" size="4" childWidth="80" childHeight="80" hSpacing="8" vSpacing="5" datamaster="fullGallery" datasizewidth="360px" datasizeheight="90px" dataX="0" dataY="132" originalwidth="344px" originalheight="80px" >\
        <div class="backgroundLayer"></div>\
        <table >\
        </table>\
      </div>\
      <div id="s-Topbar" class="pie dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="142px" dataX="0" dataY="0" >\
        <div id="s-Panel_Top" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="142px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Bg" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="132px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Bg_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="s-Menu" class="pie image firer click ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="320" dataY="34"   alt="image" systemName="./images/35a176df-8b17-42db-a602-9ba7a22555ce.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
              </div>\
\
              <div id="s-contactPhoto" class="pie image firer pageload ie-background commentable hidden non-processed"   datasizewidth="60px" datasizeheight="60px" dataX="152" dataY="31"   alt="image">\
                  <img src="./images/ed4d1f6b-b5bb-4726-8dff-74523f226b0e.png" />\
              </div>\
              <div id="s-backArrow" class="pie image firer ie-background commentable non-processed"   datasizewidth="12px" datasizeheight="22px" dataX="28" dataY="38"   alt="image" systemName="./images/8c050f26-475a-439b-8c2c-b2c9bb79332c.svg" overlay="#FFFFFF">\
                  <?xml version="1.0" encoding="UTF-8"?>\
                  <svg preserveAspectRatio=\'none\' width="12px" height="22px" viewBox="0 0 12 22" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                      <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                      <title>Fill 1</title>\
                      <desc>Created with Sketch.</desc>\
                      <defs></defs>\
                      <g id="s-backArrow-Chat" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-25.000000, -37.000000)">\
                          <g id="s-backArrow-previous-icon" transform="translate(25.000000, 37.000000)" fill="#FFFFFF">\
                              <path d="M2.65603606,11.0098815 L11.6762105,1.90747871 C12.1079298,1.47182381 12.1079298,0.762464781 11.6762105,0.32680988 C11.2441281,-0.109028223 10.5415403,-0.108845021 10.1098209,0.32680988 L0.324243364,10.20141 C0.112014645,10.4153902 0,10.688728 0,10.9917445 C0,11.2861504 0.118187251,11.5741443 0.324243364,11.7820789 L10.1020144,21.6486181 C10.3087967,21.8706592 10.5871086,21.9954199 10.8850276,21.9998168 C10.8906556,22 10.8964651,22 10.9020931,22 C11.1938395,22 11.4681574,21.884949 11.676392,21.6749992 C12.1079298,21.2393443 12.1079298,20.5303517 11.6760289,20.093964 L2.65603606,11.0098815 Z" id="s-backArrow-Fill-1"></path>\
                          </g>\
                      </g>\
                  </svg>\
              </div>\
              <div id="s-Call" class="pie image firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="26px" dataX="288" dataY="36"   alt="image" systemName="./images/62a3f813-3a9f-4072-9b84-cee96967aff7.svg" overlay="#FFFFFF">\
                  <?xml version="1.0" encoding="UTF-8"?>\
                  <svg preserveAspectRatio=\'none\' width="20px" height="26px" viewBox="0 0 20 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                      <!-- Generator: Sketch 48.1 (47250) - http://www.bohemiancoding.com/sketch -->\
                      <title>Fill 1</title>\
                      <desc>Created with Sketch.</desc>\
                      <defs></defs>\
                      <g id="s-Call-Chat" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-285.000000, -41.000000)">\
                          <g id="s-Call-call-icon" transform="translate(295.000000, 54.088000) rotate(-10.000000) translate(-295.000000, -54.088000) translate(284.000000, 43.000000)" fill="#FFFFFF">\
                              <path d="M17.1644704,14.0858784 C19.1018784,11.7568704 20.4079744,9.5841504 21.2728384,7.2509184 C21.5940384,6.3848224 22.0086944,5.0824224 21.9015104,3.7763264 C21.8494144,3.1874304 21.6271264,2.7127584 21.2026144,2.2880704 L19.2322944,0.3003264 C19.0860384,0.1616384 18.8621664,7.04e-05 18.6136544,7.04e-05 C18.5429024,7.04e-05 18.3274784,7.04e-05 18.0316224,0.2931104 L17.9825184,0.3399264 C17.6349184,0.6607744 17.2904864,1.0115424 16.9698144,1.3427744 C16.7929344,1.5317984 16.5792704,1.7454624 16.4076704,1.9170624 L14.8233184,3.5010624 C14.3637824,3.9609504 14.3637824,4.3192864 14.8234944,4.7791744 C14.9055104,4.8610144 14.9875264,4.9444384 15.0695424,5.0278624 L15.0829184,5.0414144 C15.1593024,5.1193824 15.2353344,5.1966464 15.3111904,5.2725024 L15.4493504,5.4125984 C15.8214144,5.7901184 16.2040384,6.1783744 16.5949344,6.5358304 L17.6305184,7.4825344 L17.0527104,8.7617024 C16.6320704,9.6927424 16.0558464,10.6067104 15.2395584,11.6380704 C13.5971264,13.6566144 11.8802464,15.2187904 9.9833184,16.4235104 C9.7237184,16.5850784 9.4660544,16.7137344 9.2388384,16.8274304 L9.1038464,16.8971264 C9.0142624,16.9428864 8.9274944,16.9874144 8.8409024,17.0340544 L7.5749344,17.7146464 L4.7232064,14.8718944 C4.5046144,14.6534784 4.2972864,14.5431264 4.1054464,14.5431264 C4.0380384,14.5431264 3.8328224,14.5431264 3.5399584,14.8479584 L3.5179584,14.8703104 L0.3240864,18.0759744 C0.1739584,18.2246944 7.04e-05,18.4485664 7.04e-05,18.6949664 C7.04e-05,18.9566784 0.1827584,19.2016704 0.3360544,19.3611264 C0.5351104,19.5693344 0.7551104,19.7877504 1.0305504,20.0501664 L1.1181984,20.1349984 C1.4599904,20.4653504 1.8470144,20.8395264 2.1953184,21.2598144 C2.7000864,21.7879904 3.3004224,22.0342144 4.0822144,22.0342144 C4.1665184,22.0342144 4.2590944,22.0292864 4.3479744,22.0252384 C5.9631264,21.9199904 7.4672224,21.2964224 8.7257984,20.7003104 C11.9562784,19.1384864 14.7976224,16.9120864 17.1644704,14.0858784" id="s-Call-Fill-1"></path>\
                          </g>\
                      </g>\
                  </svg>\
              </div>\
              <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="14" dataY="29"  >\
                  <div class="clickableSpot"></div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-nameHolder" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="26px" dataX="0" dataY="95" >\
        <div id="s-name" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="26px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div class="center ghostHLayout">\
              <table class="layout" summary="">\
                <tr>\
                  <td class="layout horizontal insertionpoint verticalalign name nameHolder" valign="bottom" align="center" hSpacing="4" vSpacing="0"><div id="s-contactName" class="pie label singleline autofit firer pageload ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="21px" dataX="167" dataY="5" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-contactName_0"></span></div></div></div></div><div id="shapewrapper-s-contactStatus" class="shapewrapper shapewrapper-s-contactStatus non-processed"   datasizewidth="11px" datasizeheight="11px" dataX="181" dataY="15" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-contactStatus" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-contactStatus)">\
                                  <ellipse id="s-contactStatus" class="pie ellipse shape non-processed-shape firer commentable hidden non-processed" cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-contactStatus" class="clipPath">\
                                  <ellipse cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-contactStatus" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-contactStatus_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div></td> \
                </tr>\
              </table>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Statusbar" class="pie dynamicpanel firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
        <div id="s-Panel_5" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="360px" datasizeheight="20px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Bg_1" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="81px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Bg_1_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
\
              <div id="s-Icons_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="253" dataY="0"   alt="image">\
                  <img src="./images/07bba335-9509-42a8-b78b-188d80774497.png" />\
              </div>\
              <div id="s-Label_31" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="314" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Label_31_0">15:45</span></div></div></div></div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-More_Menu" class="group firer ie-background commentable hidden non-processed" datasizewidth="164px" datasizeheight="132px" dataX="196" dataY="1" >\
        <div id="s-Bg_6" class="pie rectangle firer commentable non-processed"   datasizewidth="164px" datasizeheight="132px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_6_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_2" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_2_0">See contact</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_3" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="44" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_3_0">File</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Bg_4" class="pie rectangle firer click commentable non-processed"   datasizewidth="164px" datasizeheight="45px" dataX="0" dataY="87" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Bg_4_0">Setings</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image lockV firer ie-background commentable non-processed"   datasizewidth="54px" datasizeheight="54px" dataX="-93" dataY="428" aspectRatio="1.0"   alt="image">\
          <img src="./images/93877284-ceed-4fee-ab00-7e2d8040daf8.png" />\
      </div>\
      <div id="s-ramdonValue" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="90px" datasizeheight="16px" dataX="-129" dataY="495" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-ramdonValue_0">Ramdom Value</span></div></div></div></div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-chatDialogsProcess-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_1" class="pie gridcell firer ie-background commentable non-processed " instance="{{=it.id}}" originalwidth="343px" originalheight="165px" >\
              <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Grid_cell_1 chatDialogsProcess" valign="bottom" align="center" hSpacing="0" vSpacing="18"><div id="s-groupTo" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="328px" datasizeheight="77px" dataX="7" dataY="0" >\
                    <div id="s-Panel_3" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="328px" datasizeheight="77px" >\
                      <div class="backgroundLayer"></div>\
                      <div class="layoutWrapper scrollable">\
                          <div id="s-Image_6" class="pie image lockV firer ie-background commentable non-processed" name="PictureTo"  datasizewidth="54px" datasizeheight="54px" dataX="0" dataY="2" aspectRatio="1.0"   alt="image">\
                              <img src="{{!it.userdata["PictureTo"]}}" />\
                          </div>\
                          <div id="s-Input_9" class="pie text firer commentable non-processed"  datasizewidth="236px" datasizeheight="44px" dataX="92" dataY="7" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="DialogTo" value="{{!it.userdata["DialogTo"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
                          <div id="s-Input_10" class="pie text firer ie-background commentable non-processed"  datasizewidth="143px" datasizeheight="20px" dataX="185" dataY="56" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="TimeTo" value="{{!it.userdata["TimeTo"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
                          <div id="shapewrapper-s-Triangle_1" class="shapewrapper shapewrapper-s-Triangle_1 non-processed"  rotationdeg="270" datasizewidth="20px" datasizeheight="16px" dataX="75" dataY="21" originalwidth="20px" originalheight="16px" >\
                              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_1" class="svgContainer" style="width:100%; height:100%;">\
                                  <g>\
                                      <g clip-path="url(#clip-s-Triangle_1)">\
                                              <path id="s-Triangle_1" class="pie triangle shape non-processed-shape firer commentable non-processed" d="M 10 0 L 20 16 L 0 16 Z">\
                                              </path>\
                                      </g>\
                                  </g>\
                                  <defs>\
                                      <clipPath id="clip-s-Triangle_1" class="clipPath">\
                                              <path d="M 10 0 L 20 16 L 0 16 Z">\
                                              </path>\
                                      </clipPath>\
                                  </defs>\
                              </svg>\
                              <div class="shapert-clipping">\
                                  <div id="shapert-s-Triangle_1" class="content firer" >\
                                      <div class="valign">\
                                          <span id="rtr-s-Triangle_1_0"></span>\
                                      </div>\
                                  </div>\
                              </div>\
                          </div>\
\
                      </div>\
                    </div>\
                  </div><div id="s-groupFrom" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="328px" datasizeheight="77px" dataX="7" dataY="95" >\
                    <div id="s-Panel_4" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="328px" datasizeheight="77px" >\
                      <div class="backgroundLayer"></div>\
                      <div class="layoutWrapper scrollable">\
                          <div id="s-Image_7" class="pie image lockV firer ie-background commentable non-processed" name="PictureFrom"  datasizewidth="54px" datasizeheight="54px" dataX="274" dataY="2" aspectRatio="1.0"   alt="image">\
                              <img src="{{!it.userdata["PictureFrom"]}}" />\
                          </div>\
                          <div id="s-Input_11" class="pie text firer commentable non-processed"  datasizewidth="236px" datasizeheight="44px" dataX="0" dataY="7" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="DialogFrom" value="{{!it.userdata["DialogFrom"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
                          <div id="s-Input_12" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="0" dataY="56" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="TimeFrom" value="{{!it.userdata["TimeFrom"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
                          <div id="shapewrapper-s-Triangle_3" class="shapewrapper shapewrapper-s-Triangle_3 non-processed"  rotationdeg="90" datasizewidth="20px" datasizeheight="16px" dataX="233" dataY="21" originalwidth="20px" originalheight="16px" >\
                              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_3" class="svgContainer" style="width:100%; height:100%;">\
                                  <g>\
                                      <g clip-path="url(#clip-s-Triangle_3)">\
                                              <path id="s-Triangle_3" class="pie triangle shape non-processed-shape firer commentable non-processed" d="M 10 0 L 20 16 L 0 16 Z">\
                                              </path>\
                                      </g>\
                                  </g>\
                                  <defs>\
                                      <clipPath id="clip-s-Triangle_3" class="clipPath">\
                                              <path d="M 10 0 L 20 16 L 0 16 Z">\
                                              </path>\
                                      </clipPath>\
                                  </defs>\
                              </svg>\
                              <div class="shapert-clipping">\
                                  <div id="shapert-s-Triangle_3" class="content firer" >\
                                      <div class="valign">\
                                          <span id="rtr-s-Triangle_3_0"></span>\
                                      </div>\
                                  </div>\
                              </div>\
                          </div>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Image_2" class="pie image lockV firer ie-background commentable hidden non-processed" name="Attachment"  datasizewidth="124px" datasizeheight="124px" dataX="109" dataY="190" aspectRatio="1.0"   alt="image">\
                      <img src="{{!it.userdata["Attachment"]}}" />\
                  </div></td> \
                    </tr>\
                  </table>\
\
               </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <script type="text/x-jquery-tmpl" id="s-Attachment-template">\
        <![CDATA[\
        <td>\
          <div id="s-Grid_cell_2" class="pie gridcell firer swipeleft swiperight ie-background commentable non-processed {{? it.index>4}}hidden{{?}}" instance="{{=it.id}}" originalwidth="80px" originalheight="80px" >\
              <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Grid_cell_2 Attachment" valign="top" align="left" hSpacing="0" vSpacing="0">\
                  <div id="s-Image_1" class="pie image lockV firer click ie-background commentable non-processed" name="Image"  datasizewidth="80px" datasizeheight="80px" dataX="0" dataY="0" aspectRatio="1.0"   alt="image">\
                      <img src="{{!it.userdata["Image"]}}" />\
                  </div></td> \
                    </tr>\
                  </table>\
\
               </div>\
          </div> \
        </td>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;