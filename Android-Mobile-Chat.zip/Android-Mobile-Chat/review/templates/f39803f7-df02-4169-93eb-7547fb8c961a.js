var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="center" name="Template SlideMenu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1584566042059-ie8.css" /><![endif]-->\
      <div id="t-Menu" class="pie image firer click windowscroll ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="39px" dataX="19" dataY="29"   alt="image" systemName="./images/1a285333-4d0a-4229-8ad4-3a82b1d036b1.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
      </div>\
      <div id="t-Slidemenu" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="250px" datasizeheight="593px" dataX="-270" dataY="0" >\
        <div id="t-Panel_3" class="pie panel default firer windowscroll ie-background commentable non-processed"  datasizewidth="250px" datasizeheight="593px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="t-BG_1" class="pie rectangle firer commentable non-processed"   datasizewidth="250px" datasizeheight="593px" dataX="0" dataY="0" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-BG_1_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_1" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="130" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_1_0">Profile</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_4" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="81" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_4_0">Chats</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_3" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="543" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_3_0">Sign out</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Rectangle_2" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="179" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_2_0">Files</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Image_17" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="192"   alt="image" systemName="./images/47c731f4-eb84-4a07-9eaf-8bf9f076a8f5.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54-1.96-2.36L6.5 17h11l-3.54-4.71z"/></svg>\
              </div>\
              <div id="t-Image_71" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="94"   alt="image" systemName="./images/52ffc3da-fa29-47d3-844c-8ce41eb837ee.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>\
              </div>\
              <div id="t-Image_96" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="556"  rotationdeg="180" alt="image" systemName="./images/699c4285-f9f1-4fc6-bd98-d22475fd8271.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/></svg>\
              </div>\
              <div id="t-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="143"   alt="image" systemName="./images/9ecc2183-0b1f-4c74-a756-ec511da80569.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>\
              </div>\
              <div id="t-Menu_close" class="pie image firer click ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="39px" dataX="14" dataY="29"   alt="image" systemName="./images/1a285333-4d0a-4229-8ad4-3a82b1d036b1.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
              </div>\
              <div id="t-Rectangle_5" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="50px" dataX="0" dataY="228" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-t-Rectangle_5_0">Contacts</span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="t-Image_74" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="19" dataY="241"   alt="image" systemName="./images/dd2fc175-fadf-4214-aece-f6bea0e681a0.svg" overlay="#FFFFFF">\
                  <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="t-cover" class="pie rectangle firer click windowscroll commentable hidden non-processed"   datasizewidth="110px" datasizeheight="593px" dataX="250" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-cover_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;