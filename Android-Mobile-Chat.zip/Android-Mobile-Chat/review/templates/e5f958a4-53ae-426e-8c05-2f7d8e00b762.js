var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="1024" deviceHeight="768">\
    <div id="t-e5f958a4-53ae-426e-8c05-2f7d8e00b762" class="template growth-both devMobile canvas firer commentable non-processed" alignment="center" name="960 grid - 12 columns" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/e5f958a4-53ae-426e-8c05-2f7d8e00b762-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/e5f958a4-53ae-426e-8c05-2f7d8e00b762-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/e5f958a4-53ae-426e-8c05-2f7d8e00b762-1584566042059-ie8.css" /><![endif]-->\
      <div id="t-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="42" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="922" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="122" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="202" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_5" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="282" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_5_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_6" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="362" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_6_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_7" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="442" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_7_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_8" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="522" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_8_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_9" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="602" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_9_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_10" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="682" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_10_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_11" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="762" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_11_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Rectangle_12" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="768px" dataX="842" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_12_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;