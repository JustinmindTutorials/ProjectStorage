var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f84b1243-d701-4927-a9e9-7b5e356b21b8" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template No SlideMenu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f84b1243-d701-4927-a9e9-7b5e356b21b8-1584566042059-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;